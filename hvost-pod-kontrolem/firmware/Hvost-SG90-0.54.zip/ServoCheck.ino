#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLESecurity.h>
#include <Preferences.h>
#include <esp_system.h>

// ESP32-C3 Super Mini, SG90 signal on GPIO4. Arduino ESP32 core 3.3.3.
// Servo power is EXTERNAL regulated 5 V, with a common ground.
static constexpr uint8_t SERVO_PIN = 4;
static constexpr uint32_t PWM_HZ = 50, PWM_BITS = 14;
static constexpr uint32_t MAX_ON_MS = 2000;
static const char *SERVICE_UUID = "1f90d7a0-7d43-4d6a-a7a8-0e5347433930";
static const char *COMMAND_UUID = "1f90d7a1-7d43-4d6a-a7a8-0e5347433930";
static const char *STATUS_UUID = "1f90d7a2-7d43-4d6a-a7a8-0e5347433930";
BLECharacteristic *statusCharacteristic = nullptr;
portMUX_TYPE lock = portMUX_INITIALIZER_UNLOCKED;
bool connected = false, authenticated = false, busy = false;
bool disconnectPending = false;
int pending = 0, pendingAngle = 90; // 1 angle, 2 cycle, 3 STOP
char reply[48] = "";
uint32_t pairingPin = 0;
bool attached = false, cycle = false;
uint32_t actionStarted = 0;
int cycleStep = 0;

void respond(const char *s) {
  portENTER_CRITICAL(&lock);
  strlcpy(reply, s, sizeof(reply));
  portEXIT_CRITICAL(&lock);
}

void acceptCommand(const String &command, bool usb = false) {
  const String s = command;
  int action = 0, angle = 90;
  if (s == "STOP") action = 3;
  else if (s == "TRIGGER") action = 2;
  else if (s == "PING") { respond("READY:SG90:1"); return; }
  else if (s.startsWith("ANGLE:")) {
    String n = s.substring(6);
    if (n.length() < 2 || n.length() > 3) { respond("ERR:ANGLE"); return; }
    for (size_t i = 0; i < n.length(); ++i)
      if (n[i] < '0' || n[i] > '9') { respond("ERR:ANGLE"); return; }
    angle = n.toInt();
    if (angle < 60 || angle > 120) { respond("ERR:RANGE:60-120"); return; }
    action = 1;
  } else { respond("ERR:COMMAND"); return; }
  portENTER_CRITICAL(&lock);
  if (!usb && (!connected || !authenticated)) strlcpy(reply, "ERR:AUTH", sizeof(reply));
  else if (action != 3 && (busy || pending != 0)) strlcpy(reply, "BUSY", sizeof(reply));
  else { pending = action; pendingAngle = angle; }
  portEXIT_CRITICAL(&lock);
}

class CommandCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) override {
    String s = c->getValue();
    if (s.length() > 20) { respond("ERR:LENGTH"); return; }
    acceptCommand(s);
  }
};

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *, ble_gap_conn_desc *p) override {
    portENTER_CRITICAL(&lock);
    connected = true; authenticated = false; pending = 0;
    portEXIT_CRITICAL(&lock);
    BLESecurity::startSecurity(p->conn_handle);
  }
  void onDisconnect(BLEServer *) override {
    portENTER_CRITICAL(&lock);
    connected = false; authenticated = false; pending = 0; disconnectPending = true;
    portEXIT_CRITICAL(&lock);
    BLEDevice::startAdvertising();
  }
};

class SecurityCallbacks : public BLESecurityCallbacks {
  uint32_t onPassKeyRequest() override { return pairingPin; }
  void onPassKeyNotify(uint32_t passkey) override {
    Serial.printf("PAIRING PIN: %06lu\n", (unsigned long)passkey);
  }
  bool onConfirmPIN(uint32_t) override { return false; } // Display-only, no Just Works.
  bool onSecurityRequest() override { return true; }
  void onAuthenticationComplete(ble_gap_conn_desc *result) override {
    bool ok = result && result->sec_state.encrypted && result->sec_state.authenticated
                    && result->sec_state.key_size == 16;
    portENTER_CRITICAL(&lock);
    authenticated = ok;
    if (!ok) { pending = 0; disconnectPending = true; }
    portEXIT_CRITICAL(&lock);
    respond(ok ? "PAIRED" : "ERR:PAIRING");
  }
};

bool setAngle(int angle) {
  if (!attached) {
    attached = ledcAttach(SERVO_PIN, PWM_HZ, PWM_BITS);
    if (!attached) { respond("ERR:PWM"); return false; }
  }
  // Conservative pulse range: logical 0..180 maps to 1000..2000 us.
  // These are approximate test angles, not calibrated physical positions.
  uint32_t pulseUs = 1000 + (uint32_t)angle * 1000 / 180;
  uint32_t duty = pulseUs * ((1UL << PWM_BITS) - 1) / 20000;
  return ledcWrite(SERVO_PIN, duty);
}

void stopServo() {
  if (attached) { ledcWrite(SERVO_PIN, 0); ledcDetach(SERVO_PIN); attached = false; }
  pinMode(SERVO_PIN, OUTPUT); digitalWrite(SERVO_PIN, LOW);
  cycle = false;
  portENTER_CRITICAL(&lock); busy = false; portEXIT_CRITICAL(&lock);
}

void setup() {
  pinMode(SERVO_PIN, OUTPUT); digitalWrite(SERVO_PIN, LOW);
  Serial.begin(115200);
  BLEDevice::init("Hvost-SG90"); // RF RNG entropy before generating the device PIN.
  Preferences preferences;
  preferences.begin("hvost-servo", false);
  pairingPin = preferences.getUInt("pin", 0);
  if (pairingPin < 100000 || pairingPin > 999999) {
    pairingPin = 100000 + esp_random() % 900000;
    preferences.putUInt("pin", pairingPin);
  }
  preferences.end();
  BLEDevice::setSecurityCallbacks(new SecurityCallbacks());
  BLESecurity *security = new BLESecurity();
  security->setAuthenticationMode(ESP_LE_AUTH_REQ_SC_MITM_BOND);
  security->setCapability(ESP_IO_CAP_OUT);
  security->setInitEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
  security->setRespEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
  security->setPassKey(true, pairingPin);
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(SERVICE_UUID);
  BLECharacteristic *command = service->createCharacteristic(COMMAND_UUID,
      BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_AUTHEN);
  command->setAccessPermissions(ESP_GATT_PERM_WRITE_ENC_MITM);
  command->setCallbacks(new CommandCallbacks());
  statusCharacteristic = service->createCharacteristic(STATUS_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_READ_AUTHEN | BLECharacteristic::PROPERTY_NOTIFY);
  statusCharacteristic->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM);
  statusCharacteristic->setValue("READY:SG90:1");
  service->start();
  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();
  Serial.printf("Hvost-SG90 ready. GPIO4. PAIRING PIN: %06lu\n", (unsigned long)pairingPin);
  Serial.println("USB: INFO, ANGLE:60, ANGLE:90, ANGLE:120, TRIGGER, STOP, PING");
}

void loop() {
  static String serialLine;
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      serialLine.trim();
      if (serialLine == "INFO") Serial.printf("PAIRING PIN: %06lu\n", (unsigned long)pairingPin);
      else if (!serialLine.isEmpty()) acceptCommand(serialLine, true);
      serialLine = "";
    } else if (c != '\r') {
      if (serialLine.length() < 32) serialLine += c;
      else serialLine = "";
    }
  }
  int action, angle;
  bool disconnected;
  portENTER_CRITICAL(&lock);
  disconnected = disconnectPending; disconnectPending = false;
  action = disconnected ? 3 : pending; angle = pendingAngle; pending = 0;
  if (action == 1 || action == 2) busy = true;
  portEXIT_CRITICAL(&lock);
  if (action == 3) { stopServo(); respond("STOPPED"); }
  else if (action == 1 || action == 2) {
    actionStarted = millis(); cycle = action == 2; cycleStep = 0;
    if (!setAngle(cycle ? 90 : angle)) { stopServo(); respond("ERR:PWM"); }
    else respond(cycle ? "RUNNING" : "MOVING");
  }
  if (attached) {
    uint32_t elapsed = millis() - actionStarted;
    if (cycle && cycleStep == 0 && elapsed >= 250) { setAngle(120); cycleStep = 1; }
    if (cycle && cycleStep == 1 && elapsed >= 950) { setAngle(90); cycleStep = 2; }
    if (elapsed >= MAX_ON_MS || (cycle && elapsed >= 1650)) { stopServo(); respond("DONE"); }
  }
  char outgoing[48];
  bool canNotify;
  portENTER_CRITICAL(&lock);
  strlcpy(outgoing, reply, sizeof(outgoing)); reply[0] = 0;
  canNotify = connected && authenticated;
  portEXIT_CRITICAL(&lock);
  if (outgoing[0]) {
    Serial.println(outgoing);
    statusCharacteristic->setValue(outgoing);
    if (canNotify) statusCharacteristic->notify();
  }
  delay(2);
}
